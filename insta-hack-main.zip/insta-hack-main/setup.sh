apt-get update
apt-get upgrade
apt-get install figlet
apt install python
apt install python2
apt install git
pkg install lolcat 
pip2 install lolcat
git clone https://github.com/xero/figlet-fonts


